# RKNN deploy demo

## 1.简介

该 demo 主要用于快速验证 RKNN 的 CAPI 推理。



目前支持以下功能：

- 获取推理性能

- 获取推理结果，并保存为npy文件
  - 需要指定输入，可以是图片或npy文件。当输入为图片、且模型输入shape不匹配时，会自动做 resize 处理
  
- 若 rknn.build 时指定了 dataset、且dataset有效。则生成 rknn deploy demo时，会采用dataset的首行数据作为输出，通过 python api 的 rknn.inference 接口生成 golden 数据。板端执行demo时，会比对推理结果的余弦相似度

  **注意:** 由于 Python API 读取、缩放图片使用 opencv 库，而 rknn_deploy_demo 使用 stbi 读取、缩放图片，余弦相似度可能因此达不到0.9999



支持平台：

- [x] RK3566/RK3568/RK3588/RK3562
- [ ] RV1103/RV1103



支持特性：

- [x] 支持 RKNN API常规接口
- [x] 支持指定图片输入，输入图片尺寸不匹配时，使用 stbi 库进行 letterbox resize
- [x] 支持指定npy输入，目前只支持fp32的npy文件
- [x] 支持校验推理结果余弦距离

- [ ] RGA letterbox resize 功能
- [ ] 支持测试零拷贝
- [ ] 支持推送至板端编译



## 2.编译

指定本地 rknpu2 仓库路径（可从https://github.com/airockchip/rknpu2 获取）

```
export RKNPU2={rknpu2_path}
```

如果是编译安卓系统的demo，请指定  ANDROID_NDK_PATH 路径

```
export ANDROID_NDK_PATH={android_ndk_path}
```



编译

```
./build_android.sh {RKNPU_platform} 或 ./build_linux.sh {RKNPU_platform}
如
./build_android.sh rk3562
```



## 3.推送至板端并执行

```
adb push ./install/rknn_deploy_demo /data/rknn_deploy_demo
adb push ./model.rknn /data/rknn_deploy_demo
adb shell
cd /data/rknn_deploy_demo
export LD_LIBRARY_PATH=./lib/

执行指令有以下4种形式
执行shell脚本推理
./run.sh

只获取性能
./RKNN_deploy_demo ./model.rknn

指定输入(若 ./data/outputs_golden 存在，则推理后会计算推理结果的余弦相似度)
./RKNN_deploy_demo ./model.rknn ./data/inputs/input0.jpg

指定输入、循环跑100次(若 ./data/outputs_golden 存在，则推理后会计算推理结果的余弦相似度)
./RKNN_deploy_demo ./model.rknn ./data/inputs/input0.jpg 100
```

- **这里假设模型名字为 model.rknn，实际使用时请替换为自己 rknn 模型文件**

- **假设存在多输入 in0.npy, in1.npy，则推理指令为 ./RKNN_deploy_demo ./model.rknn ./data/inputs/in0.npy#./data/inputs/in1.npy**



## 4.打印信息与推理结果

执行demo后，可以看到以下信息

- 模型输入输出tensor的信息，包括tensor名、维度、量化类型、排布的等信息，具体含义可参考 https://github.com/airockchip/rknpu2/tree/master/doc 的 userguide 文档说明
- 模型推理时 inputs_set,  run, outputs_get 的耗时
- (如果指定了循环跑次数) 循环跑n次的平均耗时(包含 inputs set, run, outputs get)
- 如果指定了输入，会打印 rknn 推理结果与原始模型推理结果的余弦距离

以 https://github.com/rockchip-linux/rknn-toolkit2/tree/master/examples/functions/gen_cpp_rknn_deploy_demo 为例，cpp_gen_demo的推理结果如下

```
root@linaro-alip:/data/rknn_deploy_demo_Linux# ./run.sh 
rkdemo_query_model_infomodel input num: 1, output num: 1
INPUTS ATTR:
  index=0, name=data, n_dims=4, dims=[1, 224, 224, 3, ], n_elems=150528, size=150528, size_with_stride=150528, fmt=NHWC, type=INT8, qnt_type=AFFINE, zp=-13, scale=0.018317
OUTPUTS ATTR:
  index=0, name=prob, n_dims=4, dims=[1, 1000, 1, 1, ], n_elems=1000, size=2000, size_with_stride=16000, fmt=NCHW, type=FP16, qnt_type=AFFINE, zp=0, scale=1.000000

LOADING INPUT DATA
image shape match failed!, (299, 299, 3) != (224, 224, 3)
Trying resize image
Needn't letter box resize. Doing direct resize

INIT RKNN INPUT OUTPUT
rkdemo_init_input_buffer(n_api): node_index=0, size=150528, n_elems=150528, fmt=NHWC, type=UINT8
rkdemo_init_output_buffer(n_api): node_index=0, want_float=1

RUNING rknn model.
Run time for first loop
  rknn_inputs_set use: 0.967000 ms
  rknn_run use: 4.567000 ms
  rknn_outputs_get use: 0.102000 ms
SAVE OUTPUTS AS NPY
  output[0]: ./data/outputs/runtime/prob.npy
CHECK OUTPUT ACCURACY
  output[0]-[prob] cosine similarity: 0.998058
```

